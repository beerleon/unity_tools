This project contains the code for the examples used in the second
Byteman tutorial. See

  http://community.jboss.org/wiki/FaultInjectionTestingWithByteman#top

for the actual tutorial
