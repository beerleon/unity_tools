package com.test;

/**
 * This is a dummy exception.
 * 
 * @author Marcel Schoen
 * @version $Revision: 1.2 $
 * @filtered Tests the filter feature
 */
public class CustomException extends Exception {

}
