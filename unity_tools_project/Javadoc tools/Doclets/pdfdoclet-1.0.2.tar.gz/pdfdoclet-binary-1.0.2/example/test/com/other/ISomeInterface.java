package com.other;

/*
 * @(#)OtherClass.java
 */
import com.test.ISecondInterface;

/**
 * This interface extends TWO other interfaces.
 *
 * @author  Marcel Schoen
 * @version $Id: ISomeInterface.java,v 1.1 2005/12/10 11:16:13 marcelschoen Exp $
 */
public interface ISomeInterface extends IOneInterface, ITwoInterface {

}

