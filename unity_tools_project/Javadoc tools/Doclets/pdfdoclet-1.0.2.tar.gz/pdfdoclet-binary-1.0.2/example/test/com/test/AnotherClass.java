package com.test;


public class AnotherClass implements ITestInterface {

    public void initialize() throws RuntimeException;

    /*
     *  (non-Javadoc)
     * @see com.test.ITestInterface#handleAction(java.lang.Object action)
     */
    public Object handleAction(Object action) throws Exception;

}
