Plugins can be downloaded from :
- http://sonar-plugins.codehaus.org
- http://www.sonarsource.com/plugins