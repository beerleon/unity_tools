function showMessage(div_id, message) {
  $(div_id + 'msg').innerHTML = message;
  $(div_id).show();
}
function error(message) {
  showMessage('error', message);
}
function warning(message) {
  showMessage('warning', message);
}
function info(message) {
  showMessage('info', message);
}
function toggleFav(resourceId, elt) {
  $j.ajax({type: 'POST', dataType: 'json', url: baseUrl + '/favourites/toggle/' + resourceId,
    success: function (data) {
      var star = $j(elt);
      star.removeClass('fav notfav');
      star.addClass(data['css']);
      star.attr('title', data['title']);
    }});
}

function autocompleteResources() {
  $('searchInput').value = '';
  new Ajax.Autocompleter('searchInput', 'searchResourcesResults', baseUrl + '/search', {
    method: 'post',
    minChars: 3,
    indicator: 'searchingResources',
    paramName: 's',
    updateElement: function (item) {
      if (item.id) {
        window.location = baseUrl + '/dashboard/index/' + item.id;
      }
    },
    onShow: function (element, update) { /* no update */
      update.show();
    }
  });
}

var SelectBox = {
  cache: new Object(),
  init: function (id) {
    var box = document.getElementById(id);
    var node;
    SelectBox.cache[id] = new Array();
    var cache = SelectBox.cache[id];
    for (var i = 0; (node = box.options[i]); i++) {
      cache.push({value: node.value, text: node.text, displayed: 1});
    }
  },
  redisplay: function (id) {
    // Repopulate HTML select box from cache
    var box = document.getElementById(id);
    box.options.length = 0; // clear all options
    for (var i = 0, j = SelectBox.cache[id].length; i < j; i++) {
      var node = SelectBox.cache[id][i];
      if (node.displayed) {
        box.options[box.options.length] = new Option(node.text, node.value, false, false);
      }
    }
  },
  filter: function (id, text) {
    // Redisplay the HTML select box, displaying only the choices containing ALL
    // the words in text. (It's an AND search.)
    var tokens = text.toLowerCase().split(/\s+/);
    var node, token;
    for (var i = 0; (node = SelectBox.cache[id][i]); i++) {
      node.displayed = 1;
      for (var j = 0; (token = tokens[j]); j++) {
        if (node.text.toLowerCase().indexOf(token) == -1) {
          node.displayed = 0;
        }
      }
    }
    SelectBox.redisplay(id);
  },
  delete_from_cache: function (id, value) {
    var node, delete_index = null;
    for (var i = 0; (node = SelectBox.cache[id][i]); i++) {
      if (node.value == value) {
        delete_index = i;
        break;
      }
    }
    var j = SelectBox.cache[id].length - 1;
    for (var i = delete_index; i < j; i++) {
      SelectBox.cache[id][i] = SelectBox.cache[id][i + 1];
    }
    SelectBox.cache[id].length--;
  },
  add_to_cache: function (id, option) {
    SelectBox.cache[id].push({value: option.value, text: option.text, displayed: 1});
  },
  cache_contains: function (id, value) {
    // Check if an item is contained in the cache
    var node;
    for (var i = 0; (node = SelectBox.cache[id][i]); i++) {
      if (node.value == value) {
        return true;
      }
    }
    return false;
  },
  move: function (from, to) {
    var from_box = document.getElementById(from);
    var option;
    for (var i = 0; (option = from_box.options[i]); i++) {
      if (option.selected && SelectBox.cache_contains(from, option.value)) {
        SelectBox.add_to_cache(to, {value: option.value, text: option.text, displayed: 1});
        SelectBox.delete_from_cache(from, option.value);
      }
    }
    SelectBox.redisplay(from);
    SelectBox.redisplay(to);
  },
  move_all: function (from, to) {
    var from_box = document.getElementById(from);
    var option;
    for (var i = 0; (option = from_box.options[i]); i++) {
      if (SelectBox.cache_contains(from, option.value)) {
        SelectBox.add_to_cache(to, {value: option.value, text: option.text, displayed: 1});
        SelectBox.delete_from_cache(from, option.value);
      }
    }
    SelectBox.redisplay(from);
    SelectBox.redisplay(to);
  },
  sort: function (id) {
    SelectBox.cache[id].sort(function (a, b) {
      a = a.text.toLowerCase();
      b = b.text.toLowerCase();
      try {
        if (a > b) return 1;
        if (a < b) return -1;
      }
      catch (e) {
        // silently fail on IE 'unknown' exception
      }
      return 0;
    });
  },
  select_all: function (id) {
    var box = document.getElementById(id);
    for (var i = 0; i < box.options.length; i++) {
      box.options[i].selected = 'selected';
    }
  }
};


var treemaps = {};

function treemapById(id) {
  return treemaps[id];
}
var TreemapContext = function (rid, label) {
  this.rid = rid;
  this.label = label;
};

/**
 * HTML elements :
 * tm-#{id} : required treemap container
 * tm-bc-#{id} : required breadcrumb
 * tm-loading-#{id} : optional loading icon
 */
var Treemap = function (id, sizeMetric, colorMetric, heightPercents) {
  this.id = id;
  this.sizeMetric = sizeMetric;
  this.colorMetric = colorMetric;
  this.breadcrumb = [];
  treemaps[id] = this;
  this.rootNode().height(this.rootNode().width() * heightPercents / 100);
  this.initNodes();

};
Treemap.prototype.currentContext = function () {
  if (this.breadcrumb.length > 0) {
    return this.breadcrumb[this.breadcrumb.length - 1];
  }
  return null;
};
Treemap.prototype.load = function () {
  var context = this.currentContext();
  var output = '';
  this.breadcrumb.each(function (ctx) {
    output += ctx.label + '&nbsp;/&nbsp;';
  });
  $j('#tm-bc-' + this.id).html(output);
  $j('#tm-loading-' + this.id).show();
  var self = this;
  $j.ajax({
    type: "GET",
    url: baseUrl + '/treemap/index?html_id=' + this.id + '&size_metric=' + this.sizeMetric + '&color_metric=' + this.colorMetric + '&resource=' + context.rid,
    dataType: "html",
    success: function (data) {
      self.rootNode().html(data);
      self.initNodes();
      $j("#tm-loading-" + self.id).hide();
    }
  });
};
Treemap.prototype.rootNode = function () {
  return $j('#tm-' + this.id);
};

Treemap.prototype.initNodes = function () {
  var self = this;
  $j('#tm-' + this.id).find('a').each(function (index) {
    $j(this).on("click", function (event) {
      event.stopPropagation();
    });
  });
  $j('#tm-' + this.id).find('[rid]').each(function (index) {
    $j(this).on("contextmenu", function (event) {
      event.stopPropagation();
      event.preventDefault();
      // right click
      if (self.breadcrumb.length > 1) {
        self.breadcrumb.pop();
        self.load();
      } else if (self.breadcrumb.length == 1) {
        $j("#tm-loading-" + self.id).show();
        location.reload();
      }
      return false;
    });
    $j(this).on("click", function (event) {
        var source = $j(this);
        var rid = source.attr('rid');
        var has_leaves = !!(source.attr('l'));
        if (!has_leaves) {
          var context = new TreemapContext(rid, source.text());
          self.breadcrumb.push(context);
          self.load();
        }

      }
    )
  });
};

(function ($j) {
  $j.fn.extend({
    modal: function () {
      return this.each(function () {
        var obj = $j(this);
        var $link = obj.bind('click', function () {
          if ($j('#modal').length) {
            return; // another window is already opening
          }
          var $dialog = $j('<div id="modal" class="ui-widget-overlay"></div>').appendTo('body');
          var url = $link.attr('modal-url') || $link.attr('href');
          $j.get(url,function (html) {
            $dialog.removeClass('ui-widget-overlay');
            $dialog.html(html);
            $dialog
              .dialog({
                width: ($link.attr('modal-width') || 540),
                draggable: false,
                autoOpen: false,
                modal: true,
                minHeight: 50,
                resizable: false,
                close: function () {
                  $j('#modal').remove();
                }
              });
            $dialog.dialog("open");
          }).error(function () {
              alert("Server error. Please contact your administrator.");
            }).complete(function () {
              $dialog.removeClass('ui-widget-overlay');
            });

          $link.click(function () {
            $dialog.dialog('open');
            return false;
          });

          return false;
        });
      });
    },
    modalForm: function (ajax_options) {
      return this.each(function () {
        var obj = $j(this);
        obj.submit(function (event) {
          $j('input[type=submit]', this).attr('disabled', 'disabled');
          $j.ajax($j.extend({
            type: 'POST',
            url: obj.attr('action'),
            data: obj.serialize(),
            success: function (data) {
              window.location.reload();
            },
            error: function (xhr, textStatus, errorThrown) {
              $j("#modal").html(xhr.responseText);
            }
          }, ajax_options));
          return false;
        });
      });
    }
  });
})(jQuery);

function closeModalWindow() {
  $j('#modal').dialog('close');
  return false;
}

function supports_html5_storage() {
  try {
    return 'localStorage' in window && window['localStorage'] !== null;
  } catch (e) {
    return false;
  }
}

//******************* HANDLING OF DROPDOWN MENUS [BEGIN] ******************* //

var currentlyDisplayedDropdownMenu;

var hideCurrentDropdownMenu = function () {
  menu = $j('#' + currentlyDisplayedDropdownMenu);
  if (menu) {
    menu.hide();
  }
  $j(document).unbind('mouseup', hideCurrentDropdownMenu);
}

var clickOnDropdownMenuLink = function (event) {
  var link = $j(event.target).children('a');
  if (link) {
    var href = link.attr('href');
    if (href && href.length > 1) {
      // there's a real link, not a href="#"
      window.location = href;
    } else {
      // otherwise, this means that the link is handled with an onclick event (for Ajax calls)
      link.click();
    }
  }
}

function showDropdownMenu(menuId) {
  if (menuId == currentlyDisplayedDropdownMenu) {
    currentlyDisplayedDropdownMenu = "";
  } else {
    currentlyDisplayedDropdownMenu = menuId;
    $j(document).mouseup(hideCurrentDropdownMenu);
    $j('#' + currentlyDisplayedDropdownMenu + ' li').unbind('click');
    $j('#' + currentlyDisplayedDropdownMenu + ' li').click(clickOnDropdownMenuLink);
    $j('#' + currentlyDisplayedDropdownMenu).show();
  }
}

//******************* HANDLING OF DROPDOWN MENUS [END] ******************* //
