This example demonstrates how to analyze Drools projects with the Sonar Runner.

Prerequisites
=============
* [Sonar](http://www.sonarsource.org/downloads/) 3.0 or higher
* [Sonar Runner](http://docs.codehaus.org/display/SONAR/Installing+and+Configuring+Sonar+Runner) 2.0 or higher
* [Sonar Drools Plugin](http://docs.codehaus.org/display/SONAR/Drools+Plugin) 0.2 or higher

Usage
=====
* Analyze it with Sonar using the Sonar Runner:

        sonar-runner
