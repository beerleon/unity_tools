This example demonstrates how to analyze a PL/SQL project with the Sonar Runner.

Prerequisites
=============
* [Sonar](http://www.sonarsource.org/downloads/) 3.0 or higher
* [Sonar Runner](http://docs.codehaus.org/display/SONAR/Installing+and+Configuring+Sonar+Runner) 2.0 or higher
* [Sonar PL/SQL Plugin](http://www.sonarsource.com/products/plugins/languages/plsql/) 2.1 or higher

Usage
=====
* Analyze the project with Sonar using the Sonar Runner:

        sonar-runner


