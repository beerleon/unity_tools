This example demonstrates how to analyze a Cobol project with the Sonar Runner.

Prerequisites
=============
* [Sonar](http://www.sonarsource.org/downloads/) 3.0 or higher
* [Sonar Runner](http://docs.codehaus.org/display/SONAR/Installing+and+Configuring+Sonar+Runner) 2.0 or higher
* [Sonar Cobol Plugin](http://www.sonarsource.com/products/plugins/languages/cobol/) 1.11 or higher

Usage
=====
* Analyze the project with Sonar using the Sonar Runner:

        sonar-runner

