This example demonstrates how to analyze a simple JavaScript project with the Sonar Runner.

Prerequisites
=============
* [Sonar](http://www.sonarsource.org/downloads/) 3.0 or higher
* [Sonar Runner](http://docs.codehaus.org/display/SONAR/Installing+and+Configuring+Sonar+Runner) 2.0 or higher
* [Sonar JavaScript Plugin](http://docs.codehaus.org/display/SONAR/JavaScript+Plugin) 1.0 or higher

Usage
=====
* Analyze the project with Sonar using the Sonar Runner:

        sonar-runner


