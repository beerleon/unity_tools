This example demonstrates how to analyze a simple VB.NET project with the Sonar Runner.

Prerequisites
=============
* [Sonar](http://www.sonarsource.org/downloads/) 3.0 or higher
* [Sonar Runner](http://docs.codehaus.org/display/SONAR/Installing+and+Configuring+Sonar+Runner) 2.0 or higher
* [Sonar VB.NET Plugin](http://www.sonarsource.com/products/plugins/languages/vbnet/) 1.0 or higher

Usage
=====
* Analyze the project with Sonar using the Sonar Runner:

        sonar-runner
