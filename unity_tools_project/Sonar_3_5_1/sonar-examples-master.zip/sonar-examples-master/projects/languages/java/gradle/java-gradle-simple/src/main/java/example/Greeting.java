package example;

public class Greeting {
  public void coveredByUnitTest() {
   System.out.println("Hello, world.");
  }

  public void notCoveredByUnitTest() {
   System.out.println("Hello, world.");
  }
}
