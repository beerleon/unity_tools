Sample projects for the Sonar Ant Task 1.4 and previous versions can be found in the 'Prior to Sonar Ant Task 2.0' folder.
For multi-module project samples, see /projects/multi-module/ant.