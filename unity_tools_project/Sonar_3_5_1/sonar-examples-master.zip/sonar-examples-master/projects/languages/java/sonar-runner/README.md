Sample projects for Sonar Runner 1.4 and previous versions can be found in the 'Prior to Sonar Runner 2.0' folder.
For multi-module project samples, see /projects/multi-module/sonar-runner.