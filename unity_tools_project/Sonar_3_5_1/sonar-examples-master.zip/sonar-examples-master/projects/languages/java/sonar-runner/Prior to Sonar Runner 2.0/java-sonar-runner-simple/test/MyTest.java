import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class MyTest {
  @Test
  public void myTest() throws Exception {
	assertEquals(1, 1);
  }
}
