This example demonstrates how to collect code coverage by unit tests and integration tests.
Sonar aggregates these code coverages to compute an overall code coverage.

Prerequisites
=============
* [Sonar](http://www.sonarsource.org/downloads/) 3.3 or higher
* [Sonar Runner](http://docs.codehaus.org/display/SONAR/Installing+and+Configuring+Sonar+Runner) 2.0 or higher

Usage
=====
* Analyze the project with Sonar Runner:

        sonar-runner
