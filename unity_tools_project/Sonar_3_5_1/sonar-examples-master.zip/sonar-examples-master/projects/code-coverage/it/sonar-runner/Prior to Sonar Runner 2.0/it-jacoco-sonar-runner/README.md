This example demonstrates how to add information on integration tests coverage for a Java project using JaCoCo and Sonar Runner.

Prerequisites
=============
* [Sonar](http://www.sonarsource.org/downloads/) 3.0 or higher
* [Sonar Runner](http://docs.codehaus.org/display/SONAR/Installing+and+Configuring+Sonar+Runner) 1.4

Usage
=====
* Analyze it with Sonar using the Sonar Runner:

        sonar-runner